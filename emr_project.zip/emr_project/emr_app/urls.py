# emr_app/urls.py
from django.urls import path
from .views import RegisterView, process_audio, get_user_history, dashboard

urlpatterns = [
    # User registration endpoint
    path('api/register/', RegisterView.as_view(), name='register'),

    # Audio processing endpoint
    path('api/process-audio/', process_audio, name='process_audio'),

    # Fetch user history endpoint
    path('api/get-history/', get_user_history, name='get_history'),

    # Dashboard endpoint
    path('dashboard/', dashboard, name='dashboard'),
]